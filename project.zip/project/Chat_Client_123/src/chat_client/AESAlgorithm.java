package chat_client;


import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

class AESAlgorithm {
    public static String algo="AES";
    public byte[] keyvalue;
    
    public AESAlgorithm(byte[] key)
    {
        keyvalue=key;
    }
    
    public Key generatekey() throws Exception{
        Key key=new SecretKeySpec(keyvalue,algo);
        return key;
    }
    
    public  String encrypt(String m) throws Exception
    {
        Key key = generatekey();
        Cipher c=Cipher.getInstance(algo);
        c.init(Cipher.ENCRYPT_MODE, key);
        byte[] encval=c.doFinal(m.getBytes());
        String encryptedvalue=new BASE64Encoder().encode(encval);
        return encryptedvalue;
        
    }
    
    public  String decrypt(String m) throws Exception
    {
        Key key = generatekey();
        Cipher c=Cipher.getInstance(algo);
        c.init(Cipher.DECRYPT_MODE, key);
        //byte[] encval=c.doFinal(m.getBytes());
        byte[] decoderdvalue=new BASE64Decoder().decodeBuffer(m);
        byte[] decval=c.doFinal(decoderdvalue);
        String decryptedvalue=new String(decval);
        return decryptedvalue;
    }
    
}
