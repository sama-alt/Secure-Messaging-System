/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat_client;
import java.sql.*;
import javax.swing.*;

public class sqliteconnection {
    Connection con=null;
        public static Connection dbconnector()
        {
            try{
                Class.forName("org.sqlite.JDBC");
                //Connection con=DriverManager.getConnection("jdbc:sqlite:C:\\Users\\USER\\Desktop\\Employeedata.sqlite");
                Connection con=DriverManager.getConnection("jdbc:sqlite:C:\\Users\\USER\\Desktop\\project_new\\Chat_Client_123\\src\\database_1\\Employeedata.sqlite");
                //JOptionPane.showMessageDialog(null, "connection successful");
                return con;
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, e);
                return null;
            }
        }
}
