package chat_client;

import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

public class client_frame extends javax.swing.JFrame 
{
    AESAlgorithm aes;
    private byte[] keyvalue=new byte[]{'T','h','e','B','e','s','t','S','e','c','r','e','t','K','e','y'};
    String username,sender,password, address = "localhost";
    ArrayList<String> users = new ArrayList();
    //int port = 2222;
    Boolean isConnected = false;
    
    Socket sock;
    BufferedReader reader;
    PrintWriter writer;
    
    //--------------------------//
    
    public void ListenThread() 
    {
         Thread IncomingReader = new Thread(new IncomingReader());
         IncomingReader.start();
    }
    
    //--------------------------//
    
    public void userAdd(String data) 
    {
         users.add(data);
    }
    
    //--------------------------//
    
    public void userRemove(String data) 
    {
         msgbox.append(data + " is now offline.\n");
    }
    
    //--------------------------//
    
    public void writeUsers() 
    {
         String[] tempList = new String[(users.size())];
         users.toArray(tempList);
         for (String token:tempList) 
         {
             //users.append(token + "\n");
         }
    }
    
    //--------------------------//
    
    public void sendDisconnect() 
    {
        String bye = (username + ": :Disconnect");
        try
        {
            writer.println(bye); 
            writer.flush(); 
        } catch (Exception e) 
        {
            msgbox.append("Could not send Disconnect message.\n");
        }
    }

    //--------------------------//
    
    public void Disconnect() 
    {
        try 
        {
            msgbox.append("Disconnected.\n");
            sock.close();
        } catch(Exception ex) {
            msgbox.append("Failed to disconnect. \n");
        }
        isConnected = false;

    }
    
    public client_frame() 
    {
        
        initComponents();
        this.setResizable(false);
        this.setSize(880,520);
        this.setLocationRelativeTo(null);
        aes=new AESAlgorithm(keyvalue);
        tf_port.requestFocus();
         
    }
    public client_frame(boolean b) 
    {
        initComponents();
        
        this.setResizable(false);
        this.setSize(880,520);
        this.setLocationRelativeTo(null);
        aes=new AESAlgorithm(keyvalue);
        tf_port.requestFocus();
    }
    
    //--------------------------//
    
    public class IncomingReader implements Runnable {

        @Override
        public void run() {
            String[] data,usermsg;
            String stream, done = "Done", connect = "Connect", disconnect = "Disconnect", chat = "Chat";

            try {
                
                
                while ((stream = reader.readLine()) != null) {
                    data = stream.split(":");
                    /*
                    String a = data[0];
                    String enc = aes.decrypt(a);
                    usermsg=enc.split(":");
                  
                   
                   if (data[1].equals(chat)) {
                        //crypto b = new bcrypto();
                        String data1 =data[0];
                        if(usermsg[1].equals("has connected."))
                        {
                            msgbox.append(usermsg[0] + ": " + usermsg[1] + "\n");
                        }
                        else
                        t1.setText(data[0]);
                        
                   
                        //String inc = new String(b.decrypt(data1.getBytes()));
                        //msgbox.append(data[0] + ": ");
                        //msgbox.append(data[0] + ": " + data[1] + "\n");
                        //msgbox.append(data[0] + ": " + tf_chat.getText() + "\n");
                        msgbox.setCaretPosition(msgbox.getDocument().getLength());
                            
                        
                        
                    } else if (data[1].equals(connect)) {
                        msgbox.removeAll();
                        userAdd(usermsg[0]);
                    } else if (data[1].equals(disconnect)) {
                        userRemove(usermsg[0]);
                    } else if (data[1].equals(done)) {
                        //users.setText("");
                        writeUsers();
                        users.clear();
                    }
                   */
                    //msgbox.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
                   /* StyledDocument doc=t2.getStyledDocument();
                    SimpleAttributeSet left=new SimpleAttributeSet();
                    StyleConstants.setAlignment(left, StyleConstants.ALIGN_LEFT);
                    
                    SimpleAttributeSet right=new SimpleAttributeSet();
                    StyleConstants.setAlignment(right, StyleConstants.ALIGN_RIGHT);
                    int i=0;*/
                     if (data[2].equals(chat)) {
                        //crypto b = new bcrypto();
                        String data1 =data[1];
                        if(data1.equals("has connected."))
                        {
                            msgbox.append(data[0] + ": " + data1 + "\n");
                        }
                        else if(data[0].equals(sender))
                        {   
                            
                            t1.append(data[0] + ":" + data1 + ":" + "\n");
                            
                            
                            String a = data1;
                            String enc = aes.decrypt(a);
                            msgbox.append(data[0] + ": " + enc + "\n");
                            msgbox.setCaretPosition(msgbox.getDocument().getLength());
                        }
                        
                        else
                        {
                            
                           t1.append(data[0] + ":" + data1 + ":" + "\n");
                            
                            
                            String a = data1;
                            String enc = aes.decrypt(a);
                            msgbox.append(data[0] + ": " + enc + "\n");
                            msgbox.setCaretPosition(msgbox.getDocument().getLength());
                        }
                        
                    } else if (data[2].equals(connect)) {
                        msgbox.removeAll();
                        userAdd(data[0]);
                    } else if (data[2].equals(disconnect)) {
                        userRemove(data[0]);
                    } else if (data[2].equals(done)) {
                        //users.setText("");
                        writeUsers();
                        users.clear();
                    }
                        
                }
            } catch (Exception ex) {
            }
        }


    }

    //--------------------------//
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        lb_address = new javax.swing.JLabel();
        tf_address = new javax.swing.JTextField();
        lb_username = new javax.swing.JLabel();
        tf_username = new javax.swing.JLabel();
        lb_port = new javax.swing.JLabel();
        tf_port = new javax.swing.JTextField();
        b_connect = new javax.swing.JButton();
        b_disconnect = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        t1 = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        msgbox = new javax.swing.JTextArea();
        tf_chat = new javax.swing.JTextField();
        b_send = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 255, 255));
        setFocusTraversalPolicyProvider(true);
        setName("client"); // NOI18N
        setResizable(false);
        getContentPane().setLayout(null);

        jPanel2.setBackground(new java.awt.Color(51, 51, 51));

        jPanel1.setBackground(new java.awt.Color(255, 153, 0));

        lb_address.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lb_address.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lb_address.setText("Address : ");

        tf_address.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        tf_address.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tf_address.setText("localhost");
        tf_address.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf_addressActionPerformed(evt);
            }
        });

        lb_username.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lb_username.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lb_username.setText("Username :");

        tf_username.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        tf_username.setText("................................");

        lb_port.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lb_port.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lb_port.setText("Port :");

        tf_port.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        tf_port.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tf_port.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf_portActionPerformed(evt);
            }
        });

        b_connect.setBackground(new java.awt.Color(102, 255, 0));
        b_connect.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        b_connect.setIcon(new javax.swing.ImageIcon(getClass().getResource("/button/icons8-synchronize-16.png"))); // NOI18N
        b_connect.setText("Connect");
        b_connect.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        b_connect.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        b_connect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_connectActionPerformed(evt);
            }
        });

        b_disconnect.setBackground(new java.awt.Color(255, 0, 0));
        b_disconnect.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        b_disconnect.setIcon(new javax.swing.ImageIcon(getClass().getResource("/button/icons8-disconnected-16.png"))); // NOI18N
        b_disconnect.setText("Disconnect");
        b_disconnect.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        b_disconnect.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        b_disconnect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_disconnectActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lb_username, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lb_address, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tf_address, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tf_username))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(b_connect, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(71, 71, 71)
                        .addComponent(b_disconnect, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(lb_port, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tf_port, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(59, 59, 59)))
                .addGap(113, 113, 113))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lb_port, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(tf_port, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap(13, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tf_address, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lb_address, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(b_connect, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(b_disconnect, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tf_username, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lb_username, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())))
        );

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(240, 240, 240));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Encypted msg");

        t1.setColumns(20);
        t1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        t1.setRows(5);
        jScrollPane3.setViewportView(t1);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(240, 240, 240));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Decrypted msg");

        msgbox.setColumns(20);
        msgbox.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        msgbox.setRows(5);
        jScrollPane1.setViewportView(msgbox);

        b_send.setBackground(new java.awt.Color(153, 255, 255));
        b_send.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        b_send.setIcon(new javax.swing.ImageIcon(getClass().getResource("/button/icons8-email-send-32.png"))); // NOI18N
        b_send.setText("SEND");
        b_send.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        b_send.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_sendActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(181, 181, 181)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(tf_chat, javax.swing.GroupLayout.PREFERRED_SIZE, 637, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(27, 27, 27)
                            .addComponent(b_send, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 386, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 383, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(31, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE)
                    .addComponent(jScrollPane3))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tf_chat, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b_send, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 30, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 0, 876, 507);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void b_sendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_sendActionPerformed
        String nothing = "";
        if ((tf_chat.getText()).equals(nothing)) {
            tf_chat.setText("");
            tf_chat.requestFocus();
        } else {

            try {
                String data = tf_chat.getText();
                String enc = aes.encrypt(data);
                //String enc = aes.encrypt(username + ":" + t1.getText());
                //t1.append(username + ":" + data + "\n");
                //msgbox.append(username + ": " + data + "\n");
                
                writer.println(username + ":" + enc + ":" + "Chat");
                
                //writer.println(enc + ":" + "Chat");
                writer.flush(); // flushes the buffer
            } catch (Exception ex) {
                msgbox.append("Message was not sent. \n");
                ex.printStackTrace();
            }
            tf_chat.setText("");
            tf_chat.requestFocus();
        }

        tf_chat.setText("");
        tf_chat.requestFocus();
    }//GEN-LAST:event_b_sendActionPerformed

    private void b_disconnectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_disconnectActionPerformed
        sendDisconnect();
        Disconnect();
        b_connect.setText("connect");
        tf_port.setEnabled(true);
        tf_port.requestFocus();
    }//GEN-LAST:event_b_disconnectActionPerformed

    private void b_connectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_connectActionPerformed
        if (isConnected == false)
        {
            username = tf_username.getText();
            sender=username;

            try
            {
                sock = new Socket(address, Integer.parseInt(tf_port.getText()));
                InputStreamReader streamreader = new InputStreamReader(sock.getInputStream());
                reader = new BufferedReader(streamreader);
                writer = new PrintWriter(sock.getOutputStream());
                writer.println(username + ":has connected.:Connect");
                writer.flush();
                isConnected = true;
                b_connect.setText("connected");
                tf_port.disable();

            }
            catch (Exception ex)
            {
                msgbox.append("Cannot Connect! Try Again. \n");
                             }

            

            ListenThread();

        } else if (isConnected == true)
        {
            msgbox.append("You are already connected. \n");
        }
    }//GEN-LAST:event_b_connectActionPerformed

    private void tf_portActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf_portActionPerformed

    }//GEN-LAST:event_tf_portActionPerformed

    private void tf_addressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf_addressActionPerformed

    }//GEN-LAST:event_tf_addressActionPerformed

    public static void main(String args[]) 
    {
        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            @Override
            public void run() 
            {
                new client_frame().setVisible(true);
            }
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b_connect;
    private javax.swing.JButton b_disconnect;
    private javax.swing.JButton b_send;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lb_address;
    private javax.swing.JLabel lb_port;
    private javax.swing.JLabel lb_username;
    private javax.swing.JTextArea msgbox;
    public static javax.swing.JTextArea t1;
    private javax.swing.JTextField tf_address;
    private javax.swing.JTextField tf_chat;
    private javax.swing.JTextField tf_port;
    public static javax.swing.JLabel tf_username;
    // End of variables declaration//GEN-END:variables
}
